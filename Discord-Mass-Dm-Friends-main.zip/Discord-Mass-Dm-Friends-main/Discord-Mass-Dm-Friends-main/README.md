# Discord-Mass-Dm-Friends
A simple script to mass dm all of your friends

Created by: Sakori
Discord Server: https://discord.gg/tnvthKSXC9